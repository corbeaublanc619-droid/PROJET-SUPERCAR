<!DOCTYPE HTML>
<html lang=fr>
	<head>
		<meta charset = "utf-8" />
	</head>

<body>

<?php
	// mettre en ligne la connexion avec la base de données
	include ("bdconnect.php");
	

	
	// récupérer les contenus des variables formulaires
	$nom			=$_POST["name"];
	$email         	= $_POST["email"];
	$marque         = $_POST["marque"];
    $date_essai     = $_POST["date_essai"];
	$heure_essai	= $_POST["heure_essai"];

// préparer votre requête pour insérer des données dans la table PERSONNE
$demander = "insert into essai (nom,email,marque,date_essai,heure_essai) VALUES ('$nom','$email','$marque','$date_essai','$heure_essai')";
	
// exécuter la requête avec la fonction PHP
mysqli_query($bdd, $demander);
	
	
// fermeture de la connexion avec la base de données
mysqli_close($bdd);
?>
<p>
	<h2 align='center'> Merci. Veuillez patientez...</h2>
</p>