<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Nos Services</title>
  <style>
    body {
      background-image: url('fond\ essai.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      color: #fff;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    header {
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 15px 20px;
      background-color: #222;
      color: white;
      position: fixed;
      width: 100%;
      top: 0;
      left: 0;
      z-index: 1000;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
    }

    .logo p {
      font-size: 24px;
      font-weight: bold;
      margin: 0;
    }

    .logo span {
      color: #e60000;
    }

    .menu {
      list-style: none;
      display: flex;
      gap: 20px;
      margin: 0;
      padding: 0;
    }

    .menu li {
      display: inline;
    }

    .menu a {
      text-decoration: none;
      color: white;
      font-size: 16px;
      font-weight: bold;
      padding: 10px 15px;
      transition: 0.3s;
    }

    .menu a:hover {
      background-color: #e60000;
      border-radius: 5px;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 50px;
      text-align: center;
      font-family: 'Times New Roman', Times, serif;
    }
    h1{
      color:#ff0000;
    }

    .services {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
    }

    .service-card {
      background-color: white;
      border: 2px solid #0044ff;
      border-radius: 15px;
      width: 300px;
      box-shadow: 0 0 15px rgba(255, 0, 0, 0.6);
      overflow: hidden;
      text-align: left;
      margin-bottom: 20px;
    }

    .service-card img {
      width: 100%;
      height: auto;
    }

    .service-content {
      padding: 15px;
    }

    .service-title {
      color: #0044ff;
      font-size: 1.5em;
      margin-bottom: 10px;
      font-family: 'Times New Roman', Times, serif;
    }

    .service-description {
      margin-bottom: 20px;
      color: black;
      text-align: justify;
      font-family: 'Times New Roman', Times, serif;
    }

    footer {
      background-color: #333;
      color: white;
      padding: 20px 0;
      text-align: center;
    }

    .footer-bottom {
      background-color: red;
      padding: 6px;
      font-size: 10px;
    }
  </style>
</head>
<body>

<!-- HEADER comme dans l’exemple du prof -->
<header>
  <div class="logo">
    <p><span>Super</span>Cars</p>
  </div>
  <ul class="menu">
    <li><a href="index.html">Accueil</a></li>
    <li><a href="modely.php">Voitures</a></li>
    <li><a href="service.php">Services</a></li>
    <li><a href="connect.html">Demande d'essai</a></li>
    <li><a href="Contact.html">Contact</a></li>
  </ul>
</header>

<!-- CONTENU PHP + HTML -->
<div class="container">
  <h1>NOS <span style="color: white;">SERVICES</span></h1>
  <h2>Découvrez les services que nous proposons.</h2>

  <?php
  // Connexion à la base de données
  $host = "localhost";
  $dbname = "supercar";
  $username = "root";
  $password = "root";

  $bdd = mysqli_connect($host, $username, $password, $dbname);
  if (!$bdd) {
    die("Erreur de connexion : " . mysqli_connect_error());
  }

  $sql = "SELECT * FROM service";
  $curseur = mysqli_query($bdd, $sql);

  echo "<div class='services'>";
  while ($row = mysqli_fetch_assoc($curseur)) {
    echo "<div class='service-card'>";
    echo "<img src='images/" . htmlspecialchars($row['image']) . "' alt='Image service'>";
    echo "<div class='service-content'>";
    echo "<div class='service-title'>" . htmlspecialchars($row['libellé']) . "</div>";
    echo "<p class='service-description'>" . nl2br(htmlspecialchars($row['description'])) . "</p>";
    echo "</div></div>";
  }
  echo "</div>";

  mysqli_free_result($curseur);
  mysqli_close($bdd);
  ?>
</div>

<!-- FOOTER -->
<footer>
  <div class="footer-bottom">
    <p>© 2025 - TonSiteWeb.com</p>
  </div>
</footer>

</body>
</html>

