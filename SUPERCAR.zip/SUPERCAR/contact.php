<?php
include("bdconnect.php");
 
$nom = mysqli_real_escape_string($bdd, $_POST["nom"]);
$email = mysqli_real_escape_string($bdd, $_POST["email"]);
$objet = mysqli_real_escape_string($bdd, $_POST["objet"]);
$message = mysqli_real_escape_string($bdd, $_POST["message"]);
 
$ajouter = "INSERT INTO contact (nom, email, objet, message)
            VALUES ('$nom', '$email', '$objet', '$message')";
 
mysqli_query($bdd, $ajouter);
mysqli_close($bdd);
?>
   
   <!DOCTYPE HTML>
   <html lang=fr>
   <head>
   <meta charset = "UTF-8" />
   <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url(backcontact.jpg);
        }
	</style>
   </head>
   <body>
   <p>
   <h2 align='center'> Merci. Vos données sont bien insérées !!!
   <a href='Contact.html'> Retour au contact</a>
</h2>
   </p>
   </body>
   </html>