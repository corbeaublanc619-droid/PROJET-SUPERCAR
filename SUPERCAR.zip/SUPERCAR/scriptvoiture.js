document.addEventListener("DOMContentLoaded", function () {
    const searchBar = document.querySelector(".search-bar");
    const galleries = document.querySelectorAll(".gallery");
    const brandButtons = document.querySelectorAll(".brand-button");
    
    searchBar.addEventListener("input", function () {
        let filter = searchBar.value.toLowerCase();
        
        galleries.forEach(gallery => {
            let cars = gallery.querySelectorAll(".car");
            let hasVisibleCar = false;
            
            cars.forEach(car => {
                let carName = car.querySelector("h3").textContent.toLowerCase();
                if (carName.includes(filter)) {
                    car.style.display = "block";
                    hasVisibleCar = true;
                } else {
                    car.style.display = "none";
                }
            });
            
            gallery.style.display = hasVisibleCar ? "grid" : "none";
        });
    });
    
    brandButtons.forEach(button => {
        button.addEventListener("click", function () {
            let brandId = this.getAttribute("onclick").match(/'(.*?)'/)[1];
            showGallery(brandId);
        });
    });
});
