<?php
// Connexion à la base de données
require_once 'bdconnect.php'; // Ce fichier doit contenir la connexion à MySQL via mysqli

// Vérifie la connexion
if (!$bdd) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Récupération de l'ID de la demande à approuver
if (isset($_GET['id'])) {
    $id_demande = $_GET['id'];

    // Mise à jour du statut de la demande en 'Approuvée'
    $sql_update = "UPDATE essai SET statut = 'Approuvée' WHERE id = $id_demande";
    if (mysqli_query($bdd, $sql_update)) {
        echo "Demande approuvée avec succès.";
    } else {
        echo "Erreur lors de l'approbation de la demande : " . mysqli_error($bdd);
    }
} else {
    echo "ID de la demande non fourni.";
}

// Rediriger vers la page des demandes après l'action
header("Location: essais.php");
exit;
?>
