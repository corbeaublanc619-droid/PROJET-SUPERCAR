<?php 
include("bdconnect.php");
$nom      = $_REQUEST["nom_utilisateur"];
$password      = $_REQUEST["password"];

$requete = "SELECT nom_utilisateur, password
            FROM login_admin
            WHERE nom_utilisateur='$nom' AND password='$password'";
$curseur = mysqli_query($bdd, $requete);

$row = mysqli_num_rows($curseur);

if ($row == 1) {
    header("Location: accueil.html");
    exit();
}
else {
    echo " <br /><br />NOM UTILISATEUR ou/et MOT DE PASSE non-trouvé(s)<br /> ";
    echo "<a href=\"index.html\">Retour à l'authentification</a>";
}

mysqli_query($bdd, $requete);
mysqli_close($bdd);
?>