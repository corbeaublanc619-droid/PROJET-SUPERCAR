<?php 
include("bdconnect.php");

$nom = $_REQUEST["nom_utilisateur"];
$mot_de_passe = $_REQUEST["password"];

// Requête SQL corrigée : la colonne s'appelle mot_de_passe
$requete = "SELECT nom_utilisateur, mot_de_passe
            FROM login_admin
            WHERE nom_utilisateur='$nom' AND mot_de_passe='$mot_de_passe'";

$curseur = mysqli_query($bdd, $requete);

if (!$curseur) {
    die("Erreur SQL : " . mysqli_error($bdd));
}

$row = mysqli_num_rows($curseur);

if ($row == 1) {
    header("Location: dashboard.html");
    exit();
} else {
    echo "<br><br>NOM UTILISATEUR ou/et MOT DE PASSE non-trouvé(s)<br>";
    echo '<a href="index.html">Retour à l\'authentification</a>';
}

mysqli_close($bdd);
?>
