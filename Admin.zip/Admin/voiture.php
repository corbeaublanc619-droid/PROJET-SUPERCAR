
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion des Voitures</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #1e1e2e; color: white; }
        .sidebar { height: 100vh; background-color: #242424; padding: 15px; }
        .sidebar a { color: white; text-decoration: none; display: block; padding: 10px; }
        .sidebar a:hover { background-color: #444; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 d-md-block sidebar">
                <h2 class="text-center">Admin</h2>
                <a href="accueil.html">📊 Tableau de bord</a>
                <a href="voitures.php">🚗 Gestion des voitures</a>
                <a href="service.php">🚰 Gestion des services</a>
                <a href="essais.php">📋 Demandes d’essai</a>
                <a href="contact.php">📩 Messages</a>
                <a href="deconnexion.php">🔒 Déconnexion</a>
            </nav>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <h1 class="mt-4">Gestion des Voitures</h1>
                
                <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addCarModal">+ Ajouter une Voiture</button>

                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>Marque</th>
                            <th>Modèle</th>
                            <th>Description</th>
                            <th>Prix</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include ("bdconnect.php");
                        $sql = "SELECT * FROM voiture";
                        $curseur = mysqli_query($bdd, $sql);
                        while ($row = mysqli_fetch_assoc($curseur)) {
                            echo "<tr>
                                    <td>{$row['marque']}</td>
                                    <td>{$row['modèle']}</td>
                                    <td>{$row['description']}</td>
                                    <td>{$row['prix']} €</td>
                                    <td>{$row['image']}</td>
                                    <td>
                                        <div class='d-flex flex-column gap-2'>
                                            <a href='voituremodif.php?id={$row['id_voiture']}' class='btn btn-sm btn-warning'>Modifier</a>
                                            <a href='voituresupp.php?id={$row['id_voiture']}' class='btn btn-sm btn-danger' >Supprimer</a>
                                        </div>
                                    </td>
                                  </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>

    <div class="modal fade" id="addCarModal" tabindex="-1" aria-labelledby="addCarLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ajouter une Voiture</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="ajouter_voiture.php" method="POST">
                        <input type="text" class="form-control mb-2" name="marque" placeholder="Marque" required>
                        <input type="text" class="form-control mb-2" name="modele" placeholder="Modèle" required>
                        <input type="text" class="form-control mb-2" name="image" placeholder="Image URL" required>
                        <input type="number" class="form-control mb-2" name="prix" placeholder="Prix (€)" required>
                        <textarea name="description" class="form-control mb-2" placeholder="Description" rows="4"></textarea>
                        <button type="submit" class="btn btn-success w-100">Ajouter</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
