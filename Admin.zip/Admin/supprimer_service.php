<?php
$conn = new mysqli("localhost", "root", "", "zeus_car");
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "DELETE FROM service WHERE id_service = $id";
    $conn->query($sql);
}
$conn->close();
header("Location: service.php");
exit;
