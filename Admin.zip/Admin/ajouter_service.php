<?php
include ("bdconnect.php");

// Récupération des données du formulaire
$libelle = $_POST['libellé'];
$description = $_POST['description'];

// Gestion de l’image
$image_name = '';
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $upload_dir = 'uploads/';
    $image_name = basename($_FILES['image']['name']);
    $target_file = $upload_dir . $image_name;
    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
}

// Requête d'insertion
$sql = "INSERT INTO service (libellé, description, image) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $libelle, $description, $image_name);

if ($stmt->execute()) {
    // Redirection vers la page service
    header("Location: service.php");
    exit();
} else {
    echo "Erreur : " . $conn->error;
}

$conn->close();
?>
