<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "root", "supercar");
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupération des données du formulaire
$libelle = $_POST['libellé'];
$description = $_POST['description'];

// Gestion de l’image
$image_name = '';
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $upload_dir = 'uploads/';
    $image_name = basename($_FILES['image']['name']);
    $target_file = $upload_dir . $image_name;
    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
}

// Requête d'insertion
$sql = "INSERT INTO service (libellé, description, image) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $libelle, $description, $image_name);

if ($stmt->execute()) {
    // Redirection vers la page service
    header("Location: service.php");
    exit();
} else {
    echo "Erreur : " . $conn->error;
}

$conn->close();
?>
