<?php
$conn = new mysqli("localhost", "root", "root", "supercar");

if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

$id = intval($_POST['id']);
$action = $_POST['action'];

if ($action === "lu") {
    $stmt = $conn->prepare("UPDATE contact SET statut = 'lu' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
} elseif ($action === "supprimer") {
    $stmt = $conn->prepare("DELETE FROM contact WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

$conn->close();
header("Location: contact.php");
exit();
?>
