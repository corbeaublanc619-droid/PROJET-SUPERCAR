<?php
require_once 'bdconnect.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Charger les données actuelles
    $stmt = $bdd->prepare("SELECT * FROM accueil WHERE idacceuil = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $accueil = $result->fetch_assoc();

    if (!$accueil) {
        die("Entrée introuvable.");
    }

    // Traitement du formulaire
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $image = $_POST['image'];
        $libellé = $_POST['libellé'];
        $Description= $_POST['Description'];

        $update = $bdd->prepare("UPDATE accueil SET image = ?, libellé = ?, Description = ? WHERE idacceuil = ?");
        $update->bind_param("sssi", $image, $libellé, $Description, $id);

        if ($update->execute()) {
            header("Location: gestionacceuil.php");
            exit();
        } else {
            echo "Erreur lors de la mise à jour : " . $update->error;
        }
    }
} else {
    die("ID non spécifié.");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier l’accueil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
    <h2>Modifier l’accueil</h2>
    <form method="post">
        <div class="mb-3">
            <label for="image" class="form-label">image</label>
            <input type="text" name="image" class="form-control" value="<?= htmlspecialchars($accueil['image']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="libellé" class="form-label">Slogan</label>
            <input type="text" name="libellé" class="form-control" value="<?= htmlspecialchars($accueil['libellé']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="Description" class="form-label">Image (nom de fichier)</label>
            <input type="text" name="Description" class="form-control" value="<?= htmlspecialchars($accueil['Description']) ?>" required>
        </div>
        <button type="submit" class="btn btn-success">Enregistrer</button>
        <a href="gestionacceuil.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>
</body>
</html>